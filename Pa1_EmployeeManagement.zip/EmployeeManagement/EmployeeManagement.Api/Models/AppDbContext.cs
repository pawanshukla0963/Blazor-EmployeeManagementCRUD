﻿using EmployeeManagement.Models;
using Microsoft.EntityFrameworkCore;
using System;

namespace EmployeeManagement.Api.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {

        }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Department> Departments { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            //seed dept table
            modelBuilder.Entity<Department>().HasData(
                new Department { DepartmentId = 1, DepartmentName = "IT" });
            modelBuilder.Entity<Department>().HasData(
                new Department { DepartmentId = 2, DepartmentName = "HR" });
            modelBuilder.Entity<Department>().HasData(
                new Department { DepartmentId = 3, DepartmentName = "Payroll" });
            modelBuilder.Entity<Department>().HasData(
                new Department { DepartmentId = 4, DepartmentName = "Admin" });

            //seed employee table

            modelBuilder.Entity<Employee>().HasData(new Employee {
                EmployeeId = 1,
                FirstName = "Johny",
                LastName = "Hastinger",
                Email = "jher@abc.com",
                DateOfBirth = new DateTime(1980, 11, 1),
                Gender = Gender.Male,
                DepartmentId = 1,
                PhotoPath = "images/emp1.jpg"
            });
            modelBuilder.Entity<Employee>().HasData(new Employee
            {
                EmployeeId = 2,
                FirstName = "Johniie",
                LastName = "Hastingo",
                Email = "jho@abc.com",
                DateOfBirth = new DateTime(1980, 1, 2),
                Gender = Gender.Male,
                DepartmentId = 2,
                PhotoPath = "images/emp2.jpg"
            });
            modelBuilder.Entity<Employee>().HasData(new Employee
            {
                EmployeeId = 3,
                FirstName = "Johndoe",
                LastName = "Hastingerry",
                Email = "jhdo@abc.com",
                DateOfBirth = new DateTime(1980, 12, 4),
                Gender = Gender.Male,
                DepartmentId = 1,
                PhotoPath = "images/emp3.jpg"
            });
            modelBuilder.Entity<Employee>().HasData(new Employee
            {
                EmployeeId = 4,
                FirstName = "John",
                LastName = "Hasting",
                Email = "jh@abc.com",
                DateOfBirth = new DateTime(1980, 12, 4),
                Gender = Gender.Male,
                DepartmentId = 3,
                PhotoPath = "images/emp4.jpg"
            });

        }



    }
}
